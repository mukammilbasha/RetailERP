Write-Host "Installing Node Modules..."
cd app
npm install

Write-Host "Building Next.js App..."
npm run build

Write-Host "Installing PM2..."
npm install -g pm2

Write-Host "Starting Application..."
cd ..
pm2 start ecosystem.config.js

Write-Host "Saving PM2 process..."
pm2 save

Write-Host "Setup Completed Successfully!" 