# Next.js IIS Deployment

Steps:
1. Run install.ps1 as Administrator
2. Configure IIS (URL Rewrite + ARR)
3. Add website in IIS
4. Start app using start.ps1

Access:
http://localhost:3003