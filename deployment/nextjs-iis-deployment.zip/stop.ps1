pm2 stop nextjs-app
pm2 delete nextjs-app